# competition-demo

## 说明

用于演示如何调用信创大赛（噢易云赛道）接口。

## 用法

1. 安装Python 3.10或3.11。
2. 安装requirements.txt文件里的依赖库。
3. 把common.views.BaseView的api_url改为正式比赛的接口地址。
4. python manage.py runserver 0.0.0.0:8000。
5. 在浏览器访问{你的IP}:8000。